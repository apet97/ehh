
# Clankerbot

Minimal Python automation hub. Input can be a human instruction, webhook, or a cron. Output is an API call to a registered integration.

## Why
- Single-process FastAPI app.
- Pluggable integrations under `app/integrations`.
- Optional LLM parsing via DeepSeek (OpenAI-compatible API). Falls back to rule-based parser.

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # put your variables; NEVER commit .env
uvicorn app.main:app --reload
```

Open docs at: http://127.0.0.1:8000/docs

## Endpoints
- `POST /actions/parse?llm=true|false` → returns `integration, operation, params`
- `POST /actions/run` → executes the operation on an adapter
- `POST /schedules` → cron schedule the action
- `POST /webhooks/{provider}` → inbound events sent to that adapter
- `GET /healthz` → liveness

## DeepSeek usage
This repo uses **OpenAI-compatible** HTTP calls to `LLM_BASE_URL` (default `https://api.deepseek.com`).
Set `DEEPSEEK_API_KEY` and `LLM_MODEL` in `.env`. Do not hardcode secrets in the code or README.

## Example
```bash
curl -s localhost:8000/actions/parse -H 'content-type: application/json' -d '{"text":"slack.post_message channel=#general text=hello"}'

curl -s localhost:8000/actions/run -H 'content-type: application/json' -d '{"integration":"slack","operation":"post_message","params":{"channel":"#general","text":"hello from clankerbot"}}'
```

## Clockify integration
Set one of `CLOCKIFY_API_KEY` or `CLOCKIFY_ADDON_TOKEN`. Optionally set `CLOCKIFY_BASE_URL` for regional hosts.

### Examples
```bash
export CLOCKIFY_API_KEY=sk_xxx  # or CLOCKIFY_ADDON_TOKEN=...
export CLOCKIFY_BASE_URL=https://euc1.clockify.me/api  # set if your workspace is EU region

# Get user
curl -s localhost:8000/actions/run -H 'content-type: application/json' -d '{"integration":"clockify","operation":"get_user","params":{}}' | jq

# List workspaces
curl -s localhost:8000/actions/run -H 'content-type: application/json' -d '{"integration":"clockify","operation":"list_workspaces","params":{}}' | jq

# Create a client
curl -s localhost:8000/actions/run -H 'content-type: application/json' -d '{"integration":"clockify","operation":"create_client","params":{"workspaceId":"<WS_ID>","body":{"name":"ACME"}}}' | jq
```
