
from typing import Dict, Any
from .models import Action
import re, json
from app.integrations.base import list_integrations
from app.llm import client as llm_client

def parse_human(text: str) -> Action:
    text = text.strip()
    head, *rest = text.split()
    if "." not in head:
        raise ValueError("Expected 'integration.operation' at start")
    integration, operation = head.split(".", 1)
    params: Dict[str, Any] = {}
    for token in rest:
        if "=" in token:
            k, v = token.split("=", 1)
            params[k] = v
    return Action(integration=integration, operation=operation, params=params)

async def parse_with_llm(text: str) -> Action:
    # Ask LLM to extract JSON with integration, operation, params.
    choices = ", ".join(list_integrations()) or "slack"
    sys = (
        "You turn a user instruction into a JSON action for an automation hub. "
        f"Allowed integrations: {choices}. "
        "Output JSON only with keys: integration, operation, params. No prose."
    )
    user = f"Instruction: {text}"
    resp = await llm_client.chat([
        {"role": "system", "content": sys},
        {"role": "user", "content": user},
    ], temperature=0)
    content = resp["choices"][0]["message"]["content"]
    # Try to locate JSON
    start = content.find("{")
    end = content.rfind("}")
    if start >= 0 and end > start:
        obj = json.loads(content[start:end+1])
        return Action(integration=obj["integration"], operation=obj["operation"], params=obj.get("params", {}))
    raise ValueError("LLM could not return JSON action")
