
from __future__ import annotations
from typing import Dict, Any, List, Optional
import httpx
from app.config import settings

class LLMClient:
    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None, model: Optional[str] = None):
        self.base_url = (base_url or settings.LLM_BASE_URL).rstrip("/")
        self.api_key = api_key or settings.DEEPSEEK_API_KEY
        self.model = model or settings.LLM_MODEL

    async def chat(self, messages: List[Dict[str, str]], temperature: float = 0.0, stream: bool = False) -> Dict[str, Any]:
        if not self.api_key:
            raise RuntimeError("LLM API key missing")
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {"model": self.model, "messages": messages, "temperature": temperature, "stream": False}
        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(url, headers=headers, json=payload)
            r.raise_for_status()
            return r.json()

client = LLMClient()
