
from __future__ import annotations
from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="", extra="ignore")

    # LLM
    LLM_PROVIDER: str = "deepseek"
    LLM_BASE_URL: str = "https://api.deepseek.com"
    LLM_MODEL: str = "deepseek-chat"
    DEEPSEEK_API_KEY: str | None = None  # do not commit

    # Server
    CORS_ORIGINS: str = "http://localhost:3000"

    # Adapters
    SLACK_BOT_TOKEN: str | None = None

settings = Settings()
