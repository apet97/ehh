
from __future__ import annotations
from typing import Dict, Any, Optional
import os
import httpx
from app.integrations.base import Integration, register_integration
from app.config import settings

# Default base URL (global). Override via env CLOCKIFY_BASE_URL for regional hosts.
DEFAULT_BASE = os.getenv("CLOCKIFY_BASE_URL", "https://api.clockify.me/api")
# Auth: X-Api-Key or X-Addon-Token. Provide one of: CLOCKIFY_API_KEY or CLOCKIFY_ADDON_TOKEN

def _auth_headers() -> Dict[str, str]:
    api_key = os.getenv("CLOCKIFY_API_KEY")
    addon_token = os.getenv("CLOCKIFY_ADDON_TOKEN")
    if api_key:
        return {"X-Api-Key": api_key}
    if addon_token:
        return {"X-Addon-Token": addon_token}
    return {}

async def _call(method: str, path: str, *, params: Dict[str, Any] | None = None, json_body: Any | None = None) -> Dict[str, Any]:
    base = DEFAULT_BASE.rstrip("/")
    url = f"{base}{path}"
    headers = _auth_headers()
    if not headers:
        return {"ok": False, "error": "Missing CLOCKIFY_API_KEY or CLOCKIFY_ADDON_TOKEN"}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.request(method.upper(), url, headers=headers, params=params, json=json_body)
        try:
            data = r.json()
        except Exception:
            data = {"status_code": r.status_code, "text": r.text}
        # Mirror HTTP status
        if r.status_code >= 400 and "ok" not in data:
            data = {"ok": False, "status_code": r.status_code, "error": data}
        return data

@register_integration("clockify")
class ClockifyIntegration(Integration):
    async def execute(self, operation: str, params: Dict[str, Any]) -> Dict[str, Any]:
        # Minimal operations. Extend as needed.
        if operation == "get_user":
            return await _call("GET", "/v1/user", params=None)

        if operation == "list_workspaces":
            return await _call("GET", "/v1/workspaces", params=None)

        if operation == "get_workspace":
            workspace_id = params.get("workspaceId")
            if not workspace_id:
                return {"ok": False, "error": "workspaceId required"}
            return await _call("GET", f"/v1/workspaces/{workspace_id}", params=None)

        if operation == "create_client":
            workspace_id = params.get("workspaceId")
            body = params.get("body")
            if not workspace_id or not isinstance(body, dict):
                return {"ok": False, "error": "workspaceId and body required"}
            return await _call("POST", f"/v1/workspaces/{workspace_id}/clients", json_body=body)

        if operation == "list_clients":
            workspace_id = params.get("workspaceId")
            if not workspace_id:
                return {"ok": False, "error": "workspaceId required"}
            return await _call("GET", f"/v1/workspaces/{workspace_id}/clients")

        if operation == "create_time_entry":
            # Experimental: create a time entry using /v1/workspaces/{workspaceId}/time-entries
            workspace_id = params.get("workspaceId")
            body = params.get("body")
            if not workspace_id or not isinstance(body, dict):
                return {"ok": False, "error": "workspaceId and body required"}
            return await _call("POST", f"/v1/workspaces/{workspace_id}/time-entries", json_body=body)

        return {"ok": False, "error": f"unknown operation {operation}"}

    async def handle_webhook(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        # Minimal router: detect a few common event shapes and react.
        # You can fan out to Slack here if desired.
        event_type = payload.get("event") or payload.get("type")
        # Normalize common samples
        if "NEW_TIME_ENTRY" in str(event_type) or ("timeInterval" in payload and "userId" in payload and "projectId" in payload):
            return {"ok": True, "event": "TIME_ENTRY", "id": payload.get("id"), "userId": payload.get("userId")}
        if "NEW_PROJECT" in str(event_type) or ("name" in payload and "clientId" in payload and "tasks" in payload):
            return {"ok": True, "event": "PROJECT", "id": payload.get("id"), "name": payload.get("name")}
        if "APPROVAL" in str(event_type) or ("status" in payload and "owner" in payload and "dateRange" in payload):
            return {"ok": True, "event": "APPROVAL_REQUEST", "id": payload.get("id"), "status": payload.get("status", {})}
        # Fallback echo for other webhooks
        return {"ok": True, "received": True}
