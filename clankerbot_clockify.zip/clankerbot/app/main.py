
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from app.utils.logging import configure_logging
from app.config import settings
from app import scheduler as sched
from app.routes import actions as actions_routes
from app.integrations import slack  # populate registry
from app.integrations import clockify  # populate registry
from app.integrations.base import get_integration
from app.models import WebhookEnvelope

load_dotenv()
configure_logging()

app = FastAPI(title="Clankerbot", version="0.2")

# CORS
origins = [s.strip() for s in settings.CORS_ORIGINS.split(",") if s.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def _startup():
    sched.start_scheduler()

# Health
@app.get("/healthz")
async def health():
    return {"ok": True}

# Actions
app.include_router(actions_routes.router)

# Webhooks
@app.post("/webhooks/{provider}")
async def webhook(provider: str, env: WebhookEnvelope):
    integ = get_integration(provider)
    result = await integ.handle_webhook(env.payload)
    return JSONResponse(result)
