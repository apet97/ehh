
from fastapi import APIRouter, HTTPException, Query
from app.models import HumanCommand, RunActionRequest, ScheduleRequest
from app.actions import parse_human, parse_with_llm
from app.integrations.base import get_integration
from app import scheduler as sched

router = APIRouter()

@router.post("/actions/parse")
async def parse(cmd: HumanCommand, llm: bool = Query(False)):
    try:
        if not llm:
            action = parse_human(cmd.text)
        else:
            action = await parse_with_llm(cmd.text)
        return action.model_dump()
    except Exception as e:
        raise HTTPException(400, str(e))

@router.post("/actions/run")
async def run_action(req: RunActionRequest):
    integ = get_integration(req.integration)
    result = await integ.execute(req.operation, req.params)
    return result

@router.post("/schedules")
async def create_schedule(req: ScheduleRequest):
    cron = req.cron.model_dump()
    sched.schedule_action(req.integration, req.operation, req.params, cron)
    return {"scheduled": True, "cron": cron}
