
from pydantic import BaseModel, Field
from typing import Any, Dict, Optional

class HumanCommand(BaseModel):
    text: str

class Action(BaseModel):
    integration: str
    operation: str
    params: Dict[str, Any] = Field(default_factory=dict)

class RunActionRequest(Action):
    pass

class CronSpec(BaseModel):
    year: Optional[str] = None
    month: Optional[str] = None
    day: Optional[str] = None
    week: Optional[str] = None
    day_of_week: Optional[str] = None
    hour: Optional[str] = None
    minute: Optional[str] = None
    second: Optional[str] = None

class ScheduleRequest(Action):
    cron: CronSpec

class WebhookEnvelope(BaseModel):
    payload: Dict[str, Any] = Field(default_factory=dict)
